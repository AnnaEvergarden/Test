using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ContentEntry : MonoBehaviour
{
    public Image Icone;
    public Text Count;
}
